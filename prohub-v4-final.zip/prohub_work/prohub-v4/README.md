# ProHub v4 — Suite Business tout-en-un

## Installation

```bash
npm install
```

## Configuration

Copier `.env.example` en `.env` et remplir les valeurs :

```bash
cp .env.example .env
```

- `JWT_SECRET` : chaîne aléatoire longue pour signer les tokens
- `STRIPE_SECRET_KEY` : clé secrète Stripe (dashboard.stripe.com)
- `STRIPE_WEBHOOK_SECRET` : secret webhook Stripe
- `RESEND_API_KEY` : clé API Resend (resend.com)
- `RESEND_DOMAIN` : domaine vérifié sur Resend (ex: prohub.fr)
- `APP_URL` : URL publique de l'app (ex: https://prohub.fr)

## Démarrage

```bash
npm start
```

L'app tourne sur http://localhost:3000

## Nouveautés v4

- **Paramètres** accessibles à tous les plans (nom, email, mot de passe)
- **Changement d'email** avec vérification Resend sur le nouvel email
- **Espace Entreprise** avec invitations par lien fonctionnel
- **Plan Entreprise 79€/mois** avec CRM, RH, Reporting financier
- **CRM Clients** : prospects, leads, pipeline commercial
- **RH & Équipe** : employés, congés, masse salariale
- **Reporting financier** : bilan, export FEC, déclaration TVA
- **Export données** : CSV, JSON, FEC comptable
- Fix Resend : emails toujours envoyés depuis le domaine vérifié
