const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { Resend } = require('resend');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');

const app = express();
const resend = new Resend(process.env.RESEND_API_KEY);
const JWT_SECRET = process.env.JWT_SECRET || 'prohub_secret_change_this';
const DB_FILE = './db.json';

function readDB() {
  try {
    if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], codes: [], announcements: [] }));
    const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    if (!db.announcements) db.announcements = [];
    return db;
  } catch { return { users: [], codes: [], announcements: [] }; }
}
function writeDB(data) { fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2)); }
function saveUser(user) {
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === user.id);
  if (idx > -1) db.users[idx] = user; else db.users.push(user);
  writeDB(db);
}
function getUserByEmail(email) { return readDB().users.find(u => u.email === email.toLowerCase().trim()); }
function saveCode(email, code, type) {
  const db = readDB();
  db.codes = db.codes.filter(c => c.email !== email || c.type !== type);
  db.codes.push({ email: email.toLowerCase(), code, type, createdAt: Date.now() });
  writeDB(db);
}
function verifyCode(email, code, type) {
  const db = readDB();
  const entry = db.codes.find(c => c.email === email.toLowerCase() && c.code === code && c.type === type);
  if (!entry) return false;
  if (Date.now() - entry.createdAt > 10 * 60 * 1000) return false;
  db.codes = db.codes.filter(c => !(c.email === email.toLowerCase() && c.type === type));
  writeDB(db);
  return true;
}
function generateCode() { return Math.floor(100000 + Math.random() * 900000).toString(); }

// RESEND FIX: helper centralisé — from toujours depuis le domaine vérifié
async function sendEmail({ to, subject, html }) {
  return resend.emails.send({
    from: `ProHub <noreply@${process.env.RESEND_DOMAIN || 'resend.dev'}>`,
    to,
    subject,
    html
  });
}

const db0 = readDB();
if (!db0.users.find(u => u.email === 'admin@prohub.fr')) {
  db0.users.push({ id: 'admin_001', email: 'admin@prohub.fr', password: bcrypt.hashSync('admin123', 10), name: 'Administrateur', role: 'admin', emailVerified: true, createdAt: new Date().toISOString() });
  writeDB(db0);
}

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Non autorisé' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Token invalide' }); }
}
function adminMiddleware(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Accès refusé' });
  next();
}

// ═══ AUTH ═══════════════════════════════════════════════════════════════════

app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'Tous les champs sont requis.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return res.status(400).json({ error: 'Adresse email invalide.' });
  if (password.length < 6) return res.status(400).json({ error: 'Mot de passe trop court (min 6 caractères).' });
  if (getUserByEmail(email)) return res.status(400).json({ error: 'Cet email est déjà utilisé.' });
  const code = generateCode();
  saveCode(email, code, 'register');
  try {
    // RESEND FIX: on envoie sur l'email de l'utilisateur (son propre email)
    await sendEmail({
      to: email,
      subject: 'Ton code de confirmation ProHub',
      html: `<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;background:#07070f;color:#f0f0ff;padding:40px;border-radius:16px"><h1 style="color:#6c5ce7">ProHub</h1><p style="color:#7a7a9a">Suite Business tout-en-un — v4</p><h2>Confirme ton email</h2><p>Salut ${name} !</p><div style="background:#13132a;border-radius:12px;padding:24px;text-align:center;margin:24px 0"><span style="font-size:36px;font-weight:900;letter-spacing:8px;color:#6c5ce7">${code}</span></div><p style="color:#7a7a9a;font-size:13px">Expire dans 10 minutes.</p></div>`
    });
    res.json({ success: true });
  } catch (err) { console.error('RESEND ERROR:', err); res.status(500).json({ error: 'Erreur envoi email: ' + err.message }); }
});

app.post('/api/auth/verify-register', async (req, res) => {
  const { name, email, password, code } = req.body;
  if (!verifyCode(email, code, 'register')) return res.status(400).json({ error: 'Code invalide ou expiré.' });
  const newUser = { id: 'u_' + Date.now(), email: email.toLowerCase().trim(), password: bcrypt.hashSync(password, 10), name, role: 'free', emailVerified: true, createdAt: new Date().toISOString() };
  saveUser(newUser);
  const token = jwt.sign({ id: newUser.id, email: newUser.email, role: newUser.role }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ success: true, token, user: { id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role, createdAt: newUser.createdAt, emailVerified: true } });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email et mot de passe requis.' });
  const user = getUserByEmail(email);
  if (!user || !bcrypt.compareSync(password, user.password)) return res.status(401).json({ error: 'Email ou mot de passe incorrect.' });
  const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ success: true, token, user: { id: user.id, name: user.name, email: user.email, role: user.role, createdAt: user.createdAt, emailVerified: user.emailVerified } });
});

app.get('/api/auth/me', authMiddleware, (req, res) => {
  const user = readDB().users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'Utilisateur introuvable' });
  res.json({ id: user.id, name: user.name, email: user.email, role: user.role, createdAt: user.createdAt, emailVerified: user.emailVerified });
});

app.post('/api/auth/change-password', authMiddleware, (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) return res.status(400).json({ error: 'Champs requis.' });
  if (newPassword.length < 6) return res.status(400).json({ error: 'Nouveau mot de passe trop court.' });
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === req.user.id);
  if (!bcrypt.compareSync(currentPassword, db.users[idx].password)) return res.status(401).json({ error: 'Mot de passe actuel incorrect.' });
  db.users[idx].password = bcrypt.hashSync(newPassword, 10);
  writeDB(db);
  res.json({ success: true });
});

// Mettre à jour le nom (nouveau v4)
app.patch('/api/auth/update-name', authMiddleware, (req, res) => {
  const { name } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Nom requis.' });
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === req.user.id);
  if (idx === -1) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  db.users[idx].name = name.trim();
  writeDB(db);
  res.json({ success: true });
});

// Demande changement email — RESEND FIX: code envoyé sur le NOUVEL email
app.post('/api/auth/request-email-change', authMiddleware, async (req, res) => {
  const { newEmail, password } = req.body;
  if (!newEmail || !password) return res.status(400).json({ error: 'Nouvel email et mot de passe requis.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(newEmail)) return res.status(400).json({ error: 'Adresse email invalide.' });
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === req.user.id);
  if (idx === -1) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  const user = db.users[idx];
  if (!bcrypt.compareSync(password, user.password)) return res.status(401).json({ error: 'Mot de passe incorrect.' });
  if (newEmail.toLowerCase() === user.email) return res.status(400).json({ error: 'C\'est déjà votre adresse email.' });
  if (getUserByEmail(newEmail)) return res.status(400).json({ error: 'Cet email est déjà utilisé.' });
  const code = generateCode();
  saveCode(newEmail, code, 'email-change');
  try {
    // RESEND FIX: on envoie sur le NOUVEL email pour vérifier que l'utilisateur le contrôle
    await sendEmail({
      to: newEmail,
      subject: 'Confirme ton nouvel email — ProHub',
      html: `<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;background:#07070f;color:#f0f0ff;padding:40px;border-radius:16px"><h1 style="color:#6c5ce7">ProHub</h1><h2>Confirme ton nouvel email</h2><p>Une demande de changement d'email a été faite pour ce compte.</p><p>Si c'est bien toi, utilise ce code :</p><div style="background:#13132a;border-radius:12px;padding:24px;text-align:center;margin:24px 0"><span style="font-size:36px;font-weight:900;letter-spacing:8px;color:#6c5ce7">${code}</span></div><p style="color:#7a7a9a;font-size:13px">Expire dans 10 minutes. Si vous n'avez pas fait cette demande, ignorez cet email.</p></div>`
    });
    res.json({ success: true });
  } catch (err) { console.error('RESEND ERROR (email-change):', err); res.status(500).json({ error: 'Erreur envoi email: ' + err.message }); }
});

// Vérification changement email
app.post('/api/auth/verify-email-change', authMiddleware, (req, res) => {
  const { email: newEmail, code } = req.body;
  if (!newEmail || !code) return res.status(400).json({ error: 'Données manquantes.' });
  if (!verifyCode(newEmail, code, 'email-change')) return res.status(400).json({ error: 'Code invalide ou expiré.' });
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === req.user.id);
  if (idx === -1) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  db.users[idx].email = newEmail.toLowerCase().trim();
  db.users[idx].emailVerified = true;
  writeDB(db);
  const token = jwt.sign({ id: db.users[idx].id, email: db.users[idx].email, role: db.users[idx].role }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ success: true, token });
});

// Supprimer son compte
app.delete('/api/auth/account', authMiddleware, (req, res) => {
  const db = readDB();
  db.users = db.users.filter(u => u.id !== req.user.id);
  writeDB(db);
  res.json({ success: true });
});

// ═══ WORKSPACE — Invitations entreprise ═════════════════════════════════════

app.post('/api/workspace/invite', authMiddleware, async (req, res) => {
  const user = readDB().users.find(u => u.id === req.user.id);
  if (!user || !['premium2', 'enterprise', 'admin'].includes(user.role))
    return res.status(403).json({ error: 'Réservé aux comptes Premium+.' });
  const { email, role, message, workspaceName, joinLink } = req.body;
  if (!email) return res.status(400).json({ error: 'Email requis.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email))
    return res.status(400).json({ error: 'Email invalide.' });
  try {
    // RESEND FIX: invitation envoyée à l'email du collaborateur invité
    await sendEmail({
      to: email,
      subject: `Invitation à rejoindre ${workspaceName || 'un espace ProHub'}`,
      html: `<div style="font-family:Arial,sans-serif;max-width:540px;margin:auto;background:#07070f;color:#f0f0ff;padding:40px;border-radius:16px">
        <h1 style="color:#6c5ce7">ProHub</h1>
        <h2 style="color:#00cec9">Vous avez été invité !</h2>
        <p><strong>${user.name}</strong> vous invite à rejoindre l'espace <strong>${workspaceName || 'ProHub'}</strong>.</p>
        ${message ? `<div style="background:#13132a;border-radius:10px;padding:16px;margin:20px 0;font-style:italic;color:#a29bfe">"${message}"</div>` : ''}
        <p>Rôle attribué : <strong>${role || 'Membre'}</strong></p>
        <p style="color:#7a7a9a;font-size:13px">Cliquez sur le bouton ci-dessous pour rejoindre l'espace. Si vous n'avez pas encore de compte ProHub, vous pourrez en créer un gratuitement.</p>
        <a href="${joinLink || (process.env.APP_URL || 'http://localhost:3000')}" style="display:inline-block;margin-top:20px;padding:14px 32px;background:linear-gradient(135deg,#00cec9,#6c5ce7);color:#fff;border-radius:12px;text-decoration:none;font-weight:700;font-size:16px">🏢 Rejoindre l'espace →</a>
        <p style="color:#4a4a6a;font-size:12px;margin-top:20px">Si le bouton ne fonctionne pas, copiez ce lien : ${joinLink || ''}</p>
      </div>`
    });
    res.json({ success: true });
  } catch (err) { console.error('RESEND ERROR (workspace invite):', err); res.status(500).json({ error: 'Erreur envoi invitation: ' + err.message }); }
});

// ═══ PAIEMENT ════════════════════════════════════════════════════════════════

const PLANS = {
  premium_month: { price: 2000, name: 'Premium Mensuel', role: 'premium' },
  premium_year: { price: 20000, name: 'Premium Annuel', role: 'premium' },
  premium2_month: { price: 3500, name: 'Premium+ Mensuel', role: 'premium2' },
  premium2_year: { price: 30000, name: 'Premium+ Annuel', role: 'premium2' },
  enterprise_month: { price: 7900, name: 'Entreprise Mensuel', role: 'enterprise' },
  enterprise_year: { price: 79000, name: 'Entreprise Annuel', role: 'enterprise' }
};

app.post('/api/payment/create-checkout', authMiddleware, async (req, res) => {
  const { plan } = req.body;
  if (!PLANS[plan]) return res.status(400).json({ error: 'Plan invalide.' });
  const user = readDB().users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'subscription',
      customer_email: user.email,
      line_items: [{ price_data: { currency: 'eur', product_data: { name: 'ProHub ' + PLANS[plan].name }, unit_amount: PLANS[plan].price, recurring: { interval: plan.includes('year') ? 'year' : 'month' } }, quantity: 1 }],
      metadata: { userId: user.id, plan, role: PLANS[plan].role },
      success_url: (process.env.APP_URL || 'http://localhost:3000') + '/payment-success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: (process.env.APP_URL || 'http://localhost:3000') + '/?payment=cancelled'
    });
    res.json({ url: session.url });
  } catch (err) { res.status(500).json({ error: 'Erreur Stripe: ' + err.message }); }
});

app.post('/api/payment/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try { event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET); }
  catch (err) { return res.status(400).json({ error: 'Webhook invalide.' }); }
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const { userId, role } = session.metadata;
    const db = readDB();
    const idx = db.users.findIndex(u => u.id === userId);
    if (idx > -1) { db.users[idx].role = role; db.users[idx].subscribedAt = new Date().toISOString(); writeDB(db); }
  }
  res.json({ received: true });
});

app.get('/api/payment/verify/:sessionId', async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.retrieve(req.params.sessionId);
    if (session.payment_status !== 'paid') return res.json({ success: false });
    const { userId, role } = session.metadata;
    const db = readDB();
    const idx = db.users.findIndex(u => u.id === userId);
    if (idx === -1) return res.json({ success: false });
    db.users[idx].role = role; db.users[idx].subscribedAt = new Date().toISOString();
    writeDB(db);
    const token = jwt.sign({ id: db.users[idx].id, email: db.users[idx].email, role }, JWT_SECRET, { expiresIn: '30d' });
    res.json({ success: true, role, token });
  } catch (err) { res.json({ success: false }); }
});

// ═══ ADMIN ═══════════════════════════════════════════════════════════════════

app.get('/api/admin/users', authMiddleware, adminMiddleware, (req, res) => {
  res.json(readDB().users.map(u => ({ id: u.id, name: u.name, email: u.email, role: u.role, createdAt: u.createdAt, subscribedAt: u.subscribedAt, emailVerified: u.emailVerified })));
});

app.patch('/api/admin/users/:id/role', authMiddleware, adminMiddleware, (req, res) => {
  const { role } = req.body;
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  db.users[idx].role = role;
  writeDB(db);
  res.json({ success: true });
});

app.patch('/api/admin/users/:id/password', authMiddleware, adminMiddleware, (req, res) => {
  const { newPassword } = req.body;
  if (!newPassword || newPassword.length < 6) return res.status(400).json({ error: 'Mot de passe invalide.' });
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  db.users[idx].password = bcrypt.hashSync(newPassword, 10);
  writeDB(db);
  res.json({ success: true });
});

app.patch('/api/admin/users/:id/info', authMiddleware, adminMiddleware, (req, res) => {
  const { name, email } = req.body;
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  if (name) db.users[idx].name = name;
  if (email) db.users[idx].email = email.toLowerCase();
  writeDB(db);
  res.json({ success: true });
});

app.delete('/api/admin/users/:id', authMiddleware, adminMiddleware, (req, res) => {
  const db = readDB();
  db.users = db.users.filter(u => u.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

app.get('/api/admin/stats', authMiddleware, adminMiddleware, (req, res) => {
  const db = readDB();
  const users = db.users;
  const premium = users.filter(u => u.role === 'premium').length;
  const premium2 = users.filter(u => u.role === 'premium2').length;
  const mrr = premium * 20 + premium2 * 35;
  const today = new Date().toDateString();
  const newToday = users.filter(u => new Date(u.createdAt).toDateString() === today).length;
  res.json({ total: users.length, free: users.filter(u => u.role === 'free').length, premium, premium2, admins: users.filter(u => u.role === 'admin').length, mrr, arr: mrr * 12, newToday, conversionRate: users.length > 0 ? (((premium + premium2) / users.length) * 100).toFixed(1) : 0 });
});

// ═══ ANNONCES ════════════════════════════════════════════════════════════════

app.get('/api/announcements', authMiddleware, (req, res) => { res.json(readDB().announcements || []); });

app.post('/api/admin/announcements', authMiddleware, adminMiddleware, (req, res) => {
  const { message, type } = req.body;
  if (!message) return res.status(400).json({ error: 'Message requis.' });
  const db = readDB();
  if (!db.announcements) db.announcements = [];
  db.announcements.unshift({ id: 'ann_' + Date.now(), message, type: type || 'info', createdAt: new Date().toISOString() });
  db.announcements = db.announcements.slice(0, 10);
  writeDB(db);
  res.json({ success: true });
});

app.delete('/api/admin/announcements/:id', authMiddleware, adminMiddleware, (req, res) => {
  const db = readDB();
  db.announcements = (db.announcements || []).filter(a => a.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// ═══ EMAILS EN MASSE ═════════════════════════════════════════════════════════

app.post('/api/emails/send-campaign', authMiddleware, async (req, res) => {
  const user = readDB().users.find(u => u.id === req.user.id);
  if (!user || !['premium2', 'enterprise', 'admin'].includes(user.role))
    return res.status(403).json({ error: 'Accès réservé Premium+.' });
  const { subject, sender, recipients, content } = req.body;
  if (!subject || !recipients?.length || !content)
    return res.status(400).json({ error: 'Champs requis manquants.' });
  const validEmails = recipients.filter(e => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e.trim()));
  if (!validEmails.length) return res.status(400).json({ error: 'Aucun email valide.' });
  const errors = [];
  for (const email of validEmails) {
    try {
      await sendEmail({
        to: email.trim(),
        subject,
        html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:32px;background:#f9f9f9;border-radius:12px"><p style="white-space:pre-wrap;font-size:15px;color:#222;line-height:1.7">${content.replace(/</g,'&lt;').replace(/>/g,'&gt;')}</p><hr style="margin-top:32px;border:none;border-top:1px solid #ddd"><p style="font-size:11px;color:#999;margin-top:12px">Envoyé via ProHub • Expéditeur : ${sender || user.name}</p></div>`
      });
    } catch (e) { errors.push(email); }
  }
  res.json({ success: true, sent: validEmails.length - errors.length, failed: errors.length });
});

// ═══ FACTURES RÉCURRENTES ════════════════════════════════════════════════════

app.get('/api/recurrents', authMiddleware, (req, res) => {
  const user = readDB().users.find(u => u.id === req.user.id);
  res.json(user?.recurrents || []);
});

app.post('/api/recurrents', authMiddleware, (req, res) => {
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === req.user.id);
  if (idx === -1) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  if (!db.users[idx].recurrents) db.users[idx].recurrents = [];
  const rec = { ...req.body, id: 'rec_' + Date.now() };
  db.users[idx].recurrents.push(rec);
  writeDB(db);
  res.json({ success: true, rec });
});

app.patch('/api/recurrents/:id', authMiddleware, (req, res) => {
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === req.user.id);
  if (idx === -1) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  const rIdx = db.users[idx].recurrents?.findIndex(r => r.id === req.params.id);
  if (rIdx === -1 || rIdx === undefined) return res.status(404).json({ error: 'Facture introuvable.' });
  db.users[idx].recurrents[rIdx] = { ...db.users[idx].recurrents[rIdx], ...req.body };
  writeDB(db);
  res.json({ success: true });
});

app.delete('/api/recurrents/:id', authMiddleware, (req, res) => {
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === req.user.id);
  if (idx === -1) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  db.users[idx].recurrents = (db.users[idx].recurrents || []).filter(r => r.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// ═══ CRON — Factures récurrentes ═════════════════════════════════════════════

function getNextDate(current, freq) {
  const d = new Date(current);
  if (freq === 'mensuel') d.setMonth(d.getMonth() + 1);
  else if (freq === 'trimestriel') d.setMonth(d.getMonth() + 3);
  else if (freq === 'annuel') d.setFullYear(d.getFullYear() + 1);
  return d.toISOString().split('T')[0];
}

async function checkRecurringInvoices() {
  const today = new Date().toISOString().split('T')[0];
  const db = readDB();
  for (const user of db.users) {
    if (!user.recurrents?.length) continue;
    for (const rec of user.recurrents) {
      if (!rec.actif || !rec.prochainEnvoi || rec.prochainEnvoi > today) continue;
      try {
        // RESEND FIX: toujours envoyé à l'email du compte propriétaire
        await sendEmail({
          to: user.email,
          subject: `Facture récurrente — ${rec.client}`,
          html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;background:#07070f;color:#f0f0ff;padding:40px;border-radius:16px"><h1 style="color:#6c5ce7">ProHub</h1><h2 style="color:#00cec9">Facture récurrente</h2><p>Bonjour ${user.name},</p><div style="background:#13132a;border-radius:12px;padding:24px;margin:24px 0"><div style="display:flex;justify-content:space-between;margin-bottom:12px"><span style="color:#7a7a9a">Client</span><strong>${rec.client}</strong></div><div style="display:flex;justify-content:space-between;margin-bottom:12px"><span style="color:#7a7a9a">Description</span><span>${rec.desc || '—'}</span></div><div style="display:flex;justify-content:space-between;margin-bottom:12px"><span style="color:#7a7a9a">Fréquence</span><span>${rec.freq}</span></div><div style="display:flex;justify-content:space-between;border-top:1px solid rgba(255,255,255,.1);padding-top:12px;margin-top:4px"><span style="color:#7a7a9a">Montant</span><strong style="color:#00cec9;font-size:1.3rem">${rec.montant} €</strong></div></div><p style="color:#7a7a9a;font-size:13px">Envoyé automatiquement via ProHub</p></div>`
        });
        console.log(`Facture récurrente envoyée : ${user.email} — ${rec.client}`);
      } catch (e) { console.error(`Erreur facture récurrente ${rec.id}:`, e.message); }
      rec.prochainEnvoi = getNextDate(rec.prochainEnvoi, rec.freq);
    }
  }
  writeDB(db);
}

setInterval(checkRecurringInvoices, 60 * 60 * 1000);
checkRecurringInvoices();

app.get('/payment-success', (req, res) => { res.sendFile(path.join(__dirname, 'public', 'index.html')); });

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`ProHub v4 server running on port ${PORT}`));
